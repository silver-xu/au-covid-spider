export const config = {
  statsApiEndpoint: 'https://api.smartable.ai/coronavirus/stats/',
};
