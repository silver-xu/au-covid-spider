# Australia COVID-19 Data Spider [![Build Status](https://travis-ci.org/silver-xu/au-covid-spider.svg?branch=master)](https://travis-ci.org/silver-xu/au-covid-spider) [![codecov](https://codecov.io/gh/silver-xu/au-covid-spider/branch/master/graph/badge.svg)](https://codecov.io/gh/silver-xu/au-covid-spider) [![greenkeeper](https://badges.greenkeeper.io/silver-xu/au-covid-spider.svg?style=flat)](https://badges.greenkeeper.io/silver-xu/au-covid-spider.svg?style=flat)

This Spider collects COVID 19 data from the Smartable.AI Api for Australia.

It runs twice a day
